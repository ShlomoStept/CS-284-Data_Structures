package fruit;

public class Orange extends Fruit {
	// Data fields
	private double acidity;

	public Orange(double acidity, String color, Boolean seeds, double weight) {
		super(color,seeds,weight);
		this.acidity = acidity;
	}
	
	
	
	
	
}
