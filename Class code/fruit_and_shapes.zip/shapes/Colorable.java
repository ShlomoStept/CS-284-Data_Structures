package shapes;

public interface Colorable {
	
	public String getColor();
	
}
