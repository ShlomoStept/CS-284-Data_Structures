package shapes;

import fruit.Apple;
import fruit.Fruit;

public class PlayingWithShapes {

	public static void printColor(Colorable sh) {
		System.out.println("My color is "+sh.getColor());
	}

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(1.7,7.2);
		Rectangle r3 = new Rectangle(1.7,7.2, "Yellow");
		
//		System.out.println(r1.getWidth()); // prints 0.0
//		r1.setWidth(3.4);
//		System.out.println(r1.getWidth()); // prints 3.4
//		
//		System.out.println(r2.getWidth()); // prints 1.7
//		
//		System.out.println(r2);
//		
//		System.out.println(r3.getColor()); // prints Yellow
//		
//		System.out.println(Rectangle.getNoOfRectangles()); // prints 2
//		
		Circle c1 = new Circle(3.4);
		
//		System.out.println(c1.getRadius());
//		System.out.println(c1);
//		System.out.println(c1.getColor());
		
		
		Apple a1 = new Apple("Fiji","Red",false,0.2);

		printColor(r3);
		printColor(c1);
		printColor(a1);

		
		Colorable[] ss = new Colorable[3];
		
		ss[0]=r1;
		ss[1]=c1;
		ss[2]=a1;
		
		
		for (Colorable s:ss) {
			printColor(s);
		}
		
	}
	
	
}
