module cs284s21 {
	exports shapes;
}