package mylist;

public class MyList<E> {
	// data fields
	private E[] data;
	private int free;
	
	public MyList(int size) {
		super();
		this.data = ((E[]) new Object[size]);
		this.free = 0;
	}

	// Methods
	public void addFirst(E item) {
		return;
	}
	
	public void addAt(E item, int index) {
		return;
	}
	
	public E getFirst() {
		return null;
	}
	
	public E getAt(int index) {
		return null;
	}
		
	public E removeFirst() {
		return null;
	}
	
	public E removeAt(int index) {
		return null;
	}
	
	public String toString() {
		return null;
	}
	
	public static void main(String[] args) {
		MyList<String> l = new MyList<>(20);
		
		l.addFirst("hello");
		l.addFirst("bye");
		
		System.out.println(l);
	}
	
	
}
