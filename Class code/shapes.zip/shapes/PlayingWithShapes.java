package shapes;

public class PlayingWithShapes {

	
	public static void main(String[] args) {
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(1.7,7.2);
		Circle c1 = new Circle(3.4);
		
		System.out.println(r1.getWidth()); // prints 0.0
		r1.setWidth(3.4);
		System.out.println(r1.getWidth()); // prints 3.4
		
		System.out.println(r2.getWidth()); // prints 1.7
		
		System.out.println(r2);
		
		System.out.println(Rectangle.getNoOfRectangles());
		
		System.out.println(c1.getRadius());
		
		c1.setColor("Green");
		System.out.println(c1.toString());
		
		Rectangle r3 = new Rectangle(1.4, 5.3, "Yellow");
		
		System.out.println(r3.getColor());
	}
	
	
	
}
